let ws;
let localStream;
let remoteStream;
let peerConnection;

const myVid = document.getElementById('my-video');
const peerVid = document.getElementById('peer-video');
const videoBtn = document.getElementById('video-ctl');
const endCallBtn = document.getElementById('endcall');
const audioBtn = document.getElementById('audio-ctl');

const env = {};

if (location.hostname == 'localhost') {
	env.ws = 'ws://localhost:8787';
	env.servers = { iceServers: [{ urls: 'stun:stun.cloudflare.com:3478' }] };
} else {
	//TODO
}
